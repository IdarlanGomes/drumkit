﻿=== Drummers Kit Cursor Set ===

By: dp

Download: http://www.rw-designer.com/cursor-set/dig-the-beat

Author's description:

if you're a drummer, or lover of drums. this set of cursors is yours too. i loved making them, and have a lot more too. just i got pc troubles and got to go now and fix it.
enjoy using these as much as i did making them and your going on up to the higher love.
dig the beat...peace
use for you, but don't sell them, or az will find you

==========

License: Creative Commons - Noncommercial

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Noncommercial - You may not use this work for commercial purposes.